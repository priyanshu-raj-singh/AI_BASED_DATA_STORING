const express = require('express');
const { OpenAI } = require('openai');
const dotenv = require('dotenv');

dotenv.config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const router = express.Router();

// Endpoint to generate data story
router.post('/generate', async (req, res) => {
    const { prompt } = req.body;

    if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
    }

    try {
        // Generate the data story using OpenAI's GPT-3 model
        const response = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [{ role: 'user', content: prompt }],
        });

        const story = response.choices[0].message.content;

        // Return the generated story
        res.json({ story });
    } catch (error) {
        console.error("Error generating story: ", error);
        res.status(500).json({ message: "Internal server error" });
    }
});

module.exports = router;
