const express = require('express');
const { ClerkExpressWithAuth } = require('@clerk/clerk-sdk-node');

const router = express.Router();

// Google Sign In (handled by Clerk)
router.post('/sign-in', ClerkExpressWithAuth(), (req, res) => {
    if (!req.auth) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    // Return the user's information after successful authentication
    res.json({ user: req.auth.user });
});

module.exports = router;
